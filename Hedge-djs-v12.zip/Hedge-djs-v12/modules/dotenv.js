const {readFileSync} = require("fs");

module.exports = class Env {
    constructor(path = "./.env") {
        const file = readFileSync(path, 'utf-8').split(/\r?\n/g);

        for (const env of file) {
            if (!env || env.startsWith("#")) continue;
            const string = env.split("=");
            process.env[string[0]] = string[1];
        }
    }
}